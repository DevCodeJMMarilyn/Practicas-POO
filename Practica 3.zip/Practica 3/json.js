

inputDate.addEventListener()


class Persona{
    constructor(nombre, genero, fechaNacimiento){
        this.nombre=nombre
        this.genero=genero
        this.fechaNacimiento= fechaNacimiento
    }
}

const inputDate= document.getElementById("fecha")
const botonEvaluar=document.getElementById("evaluar")


botonEvaluar.addEventListener("click",()=>{

    let inputNombre=document.getElementById("nombre").value
    let inputGenero=document.getElementById("genero").value
    let labelResultado=document.getElementById(fechaNacimiento).value
})