const botonEvaluar=document.getElementById("evaluar")
const check=document.getElementById("descuento")

check.addEventListener("change", ()=>{
    if(check.cheked){
        estado=true
    }else{
        estado=false
    }
})



botonEvaluar.addEventListener("click",()=>{
    let selectBebida=document.getElementById("bebidas").value

    const objetoBebida={
        coca:"0.75",
        pepsi:"0.75",
        up: "0.75",
        pilsener: "1.00"
    }
    if(estado){
        
    }

    console.log(objetoBebida[selectBebida])
})


